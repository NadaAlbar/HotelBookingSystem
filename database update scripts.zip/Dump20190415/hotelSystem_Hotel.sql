-- MySQL dump 10.13  Distrib 8.0.13, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: hotelSystem
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Hotel`
--

DROP TABLE IF EXISTS `Hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Hotel` (
  `hotel_id` int(11) NOT NULL,
  `hotel_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Hotel`
--

LOCK TABLES `Hotel` WRITE;
/*!40000 ALTER TABLE `Hotel` DISABLE KEYS */;
INSERT INTO `Hotel` VALUES (1001,'Courtyard Marriott ','310 S. COLLEGE AVENUE','Newyork','(216) 881-3000 ','NY'),(1002,'Hampton Inn','1710 N. KINSER PIKE','Washington','(216) 881-4973 ','DC'),(1003,'Days Inn ','120 S FAIRFIELD DRIVE','Pittsburgh','(216) 881-4589 ','PA'),(1004,'Comfort Inn ','2100 N WALNUT STREET','Los Angeles','(216) 881-3027 ','CA'),(1005,'Quality Inn','200 E. STATE ROAD ','Newyork','(216) 881-2424 ','NY'),(1006,'Country Heart Inn','1399 LIBERTY DRIVE','Chicago','(216) 432-3505 ','IL'),(1007,'A Summerhouse ','2615 EAST THIRD STREET','Miami','(216) 881-3000 ','FL'),(1008,'Hilton Garden Inn ','1751 NORTH STONELAKE DRIVE','Orlando','(216) 881-4973 ','FL'),(1009,'Bloomington Travelodge','1722 N WALNUT ST','Denver','(216) 881-4589 ','CO'),(1010,'Quality Inn','4501 EAST 3RD STREET','Washington','(216) 881-3027 ','DC'),(1011,'Country Heart Inn','245 N. COLLEGE AVE','Pittsburgh','(216) 881-2424 ','PA'),(1012,'Holiday Inn Express','105 SOUTH FRANKLIN','Pittsburgh','(216) 432-3505 ','PA'),(1013,' Super 8 Motel','1399 LIBERTY DRIVE','Las vegas','(216) 881-4589 ','CA'),(1014,'Homewood Suites ','117 S. FRANKLIN ROAD ','Cleveland','(216) 881-3027 ','OH'),(1015,'','','','',NULL),(1016,'','','','',NULL),(1017,'','','','',NULL),(1018,'','','','',NULL),(1019,'','','','',NULL),(1020,'','','','',NULL);
/*!40000 ALTER TABLE `Hotel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-15  4:09:35
