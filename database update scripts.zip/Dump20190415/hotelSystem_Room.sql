-- MySQL dump 10.13  Distrib 8.0.13, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: hotelSystem
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Room`
--

DROP TABLE IF EXISTS `Room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `Room` (
  `room_id` int(11) NOT NULL,
  `room_type` varchar(45) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `room_num` varchar(45) DEFAULT NULL,
  `num_guests` varchar(45) DEFAULT NULL,
  `hotel` int(11) NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `hotel` (`hotel`),
  CONSTRAINT `room_ibfk_1` FOREIGN KEY (`hotel`) REFERENCES `hotel` (`hotel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Room`
--

LOCK TABLES `Room` WRITE;
/*!40000 ALTER TABLE `Room` DISABLE KEYS */;
INSERT INTO `Room` VALUES (1012,'queen',190,'123','4',1001),(1014,'queen',180,'134','2',1002),(1016,'queen',170,'234','2',1001),(1018,'standard double',200,'532','4',1002),(1019,'standard double',200,'533','4',1002),(1020,'queen',199,'455','2',1003),(1022,'King',230,'567','2',1004),(1024,'standard double',210,'432','4',1005),(1026,'King',220,'345','2',1006),(1028,'King',210,'678','2',1007),(1030,'King',215,'346','2',1008),(1032,'twin',199,'643','4',1009),(1034,'standard double',194,'536','4',1010),(1036,'standard double',188,'435','4',1011),(1038,'King',201,'577','2',1012),(1040,'junior suite',195,'953','5',1013),(1041,'junior suite',195,'953','5',1013),(1051,'queen',199,'455','2',1003);
/*!40000 ALTER TABLE `Room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-15  4:09:34
