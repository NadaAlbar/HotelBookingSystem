-- MySQL dump 10.13  Distrib 8.0.13, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: hotelSystem
-- ------------------------------------------------------
-- Server version	8.0.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customer` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(250) DEFAULT NULL,
  `Lname` varchar(250) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address_line1` varchar(45) DEFAULT NULL,
  `address_line2` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Nada','Albar','4128334503','lkj@pitt.edu','4536 Center ave','apt 876','Pittsburgh ','PA','15230'),(2,'Sara','Ali','5436778923','b@pitt.edu','143 Northlake dr','apt 4507','Atlanta','GA','14302'),(19,'Alex','Green','1114335234','Alex@pitt.edu','567 Fifth ave','apt 505','Dallas','TX','12031'),(20,'Bob','NA','6548887654','Bob@pitt.edu','345 Center Ave','apt 543','Rochester','NY','10234'),(22,'Ned','alsj','3232323232','lkj@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12989'),(23,'Neda','Albar','4123455666','nada@pitt.edu','2345 penn','32323','Pitt','oeiu','12213'),(24,'Ned','alsj','3232323232','lkj@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12989'),(25,'Ned','alsj','4123455666','nada@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12314'),(26,'Ned','alsj','2323232323','lkj@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12031'),(27,'Ned','alsj','3232323232','lkj@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12989'),(28,'Ned','alsj','4123455666','nada@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12314'),(29,'Ned','alsj','4123455666','nada@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12314'),(30,'Ned','alsj','4123455666','nada@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12314'),(31,'Neda','Albar','4123455666','nada@pitt.edu','2345 penn','32323','Pitt','oeiu','12213'),(32,'Ned','alsj','4123455666','nada@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12314'),(33,'Ned','alsj','2323232323','lkj@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12031'),(34,'Ned','alsj','4123455666','nada@pitt.edu','d.klj','eqlkej','kjkljh','kasdljaskldj','12314'),(35,'Bashayer','Halawani','4123447645','BH@pitt.edu','983 Memory Lane','apt 3423','Pittsburgh','PA','15487');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-15  4:09:33
